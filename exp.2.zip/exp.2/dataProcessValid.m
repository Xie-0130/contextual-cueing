function Out = dataProcessValid(dataOut, ntrainEp,ntestEp, subNum)
try

    %training session RT analysis
    %Valid
    %calculate mean RT of each subject and each condition
    mrSubTrain = grpstats(dataOut.valid,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubTrain.mean_RT = mrSubTrain.mean_RT .*1000;  
    Out.mrSubTrain = mrSubTrain;
    
    reshape(mrSubTrain.New, subNum,[])
    reshape(mrSubTrain.NE, subNum,[])
    reshape(mrSubTrain.nSub, subNum,[])
    
    Out.spssRTTrainEp = reshape(mrSubTrain.mean_RT, subNum,[]);          
   %% for error bar within subject design   
    adjustRT = adjustErrorBar(Out.spssRTTrainEp, subNum);         
    [mL eL cL gL] = grpstats(adjustRT,{Out.mrSubTrain.New Out.mrSubTrain.NE},{'mean', 'sem','numel','gname'}); 
 
    %% transfer session 1
    mrSubtest1 = grpstats(dataOut.test1.valid,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubtest1.mean_RT = mrSubtest1.mean_RT .*1000;

    Out.mrSubtest1 = mrSubtest1;
    Out.spssRTSubEptest1 = reshape(mrSubtest1.mean_RT, subNum,[]);          
    %% for error bar within subject design   
     adjustRT = adjustErrorBar(Out.spssRTSubEptest1, subNum);         
    [mT1 eT1 cT1 gT1] = grpstats(adjustRT,{mrSubtest1.New mrSubtest1.NE},{'mean', 'sem','numel','gname'}); 

    %% transfer session 2
    mrSubtest2 = grpstats(dataOut.test2.valid,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
     mrSubtest2.mean_RT = mrSubtest2.mean_RT .*1000;

    Out.mrSubtest2 = mrSubtest2;
    Out.spssRTmrSubEptest2 = reshape(mrSubtest2.mean_RT, subNum,[]);          
    %% for error bar within subject design   
    adjustRT = adjustErrorBar(Out.spssRTmrSubEptest2, subNum);         
    [mT2 eT2 cT2 gT2] = grpstats(adjustRT,{mrSubtest2.New mrSubtest2.NE},{'mean', 'sem','numel','gname'}); 

       %% transfer session 3
    mrSubtest3 = grpstats(dataOut.test3.valid,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
     mrSubtest3.mean_RT = mrSubtest3.mean_RT .*1000;

    Out.mrSubtest3 = mrSubtest3;
    Out.spssRTmrSubEptest3 = reshape(mrSubtest3.mean_RT, subNum,[]);          
    %% for error bar within subject design   
    adjustRT = adjustErrorBar(Out.spssRTmrSubEptest3, subNum);         
    [mT3 eT3 cT3 gT3] = grpstats(adjustRT,{mrSubtest3.New mrSubtest3.NE},{'mean', 'sem','numel','gname'}); 
   
   % plot results of training session  
      figure(); hold on;set(gcf,'Units','inches','Position',[1 1 7 5] );
      set(gca,'Position',[0.25 0.16 0.68 0.68] );
      set(gca,'ytick',550:40:850);
      set(gca,'xtick',0:2:14);
      set(gca,'fontsize',14);
      set(gca,'fontname','Arial');
      f1=errorbar(1 : ntrainEp, mL(1: ntrainEp), eL(1: ntrainEp),'k-O');
      f2=errorbar(1 : ntrainEp, [mL(ntrainEp+1:ntrainEp*2)], [eL(ntrainEp+1:ntrainEp*2)],'k-*');
    
      errorbar(ntrainEp:ntrainEp+ntestEp,[mL(ntrainEp);mT1(1)],[eL(ntrainEp);eT1(1)],'k--O');
      errorbar(ntrainEp:ntrainEp+ntestEp,[mL(ntrainEp*2);mT1(2)],[eL(ntrainEp*2);eT1(2)],'k--*');
        
      errorbar(ntrainEp+ntestEp:ntrainEp+ntestEp*2, [mT1(1); mT2(1)], [eT1(1); eT2(1)],'k--O');
      errorbar(ntrainEp+ntestEp:ntrainEp+ntestEp*2, [mT1(2); mT2(2)], [eT1(2); eT2(2)],'k--*');

      errorbar(ntrainEp+ntestEp*2:ntrainEp+ntestEp*3, [mT2(1); mT3(1)], [eT2(1); eT3(1)],'k--O');
      errorbar(ntrainEp+ntestEp*2:ntrainEp+ntestEp*3, [mT2(2); mT3(2)], [eT2(2); eT3(2)],'k--*');
   
      text(4.83,645,'**');
      text(6.91,640,'*');
      text(7.81,630,'**');
      text(9.82,630,'**');
      text(10.82,780,'**');
      text(11.81,776,'**'); 
      text(12.71,780,'***');
      text(3,800,'Learning phase','fontsize',14); 
      text(11.2,800,'Test phase','fontsize',14);
      text(-2.5,870,'B','fontsize',16);
      ylabel('Mean response time (ms)','fontsize',14,'fontweight','bold')
      xlabel('Epoch','fontsize',14,'fontweight','bold');
      plot([10.5 10.5],[550,850],'k');
      legend([f1,f2],'Repeated','Novel');
      set(legend,'box','off');
      hold off;
    
catch ME
    disp(ME.message);
end