function Out = ErrorProcess(dataErr,dataTestErr,nExp, subNum,nEp,ntestEp)
try
    dataOut.mL = [ ];
    dataOut.eL = [];
    dataTestOut.mT = [ ];
    dataTestOut.eT = [];
    for iExp = 1:nExp
        dataCurr = dataErr(dataErr.nExp == iExp, :);
        %training session RT analysis
        mrSubTrain = grpstats(dataCurr,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
        if iExp == 2
            mrSubTrainTable = checkMissingCond(mrSubTrain,nEp, subNum);
            mrSubTrainTable.numel_RT = mrSubTrainTable.numel_RT ./0.6;
            mrSubTrain = mrSubTrainTable
        else
            mrSubTrain.numel_RT = mrSubTrain.numel_RT ./0.6;%Calculate error rate
        end
        Out.mrSubTrain = mrSubTrain;
        reshape(mrSubTrain.New, subNum,[])
        reshape(mrSubTrain.NE, subNum,[])
        reshape(mrSubTrain.nSub, subNum,[])
        Out.spssRTTrainEp = reshape(mrSubTrain.numel_RT, subNum,[]);
        %% for error bar within subject design
        adjustRT = adjustErrorBar(Out.spssRTTrainEp, subNum);
        [mL eL cL gL] = grpstats(adjustRT,{mrSubTrain.New mrSubTrain.NE},{'mean', 'sem','numel','gname'});
        dataOut.mL = [dataOut.mL,mL];
        dataOut.eL = [dataOut.eL,eL];
    end
    %% transfer session (test1:i=11;test2:i=12;test3:i=13)
    for i = 11:13
        dataTestCurr = dataTestErr(dataTestErr.NE == i, :);
        mrSubtest = grpstats(dataTestCurr,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
        mrSubtestTable = checkMissingCond(mrSubtest,ntestEp,subNum);
        mrSubtestTable.numel_RT = mrSubtestTable.numel_RT ./0.6;
        Out.spssRTSubEptest = reshape(mrSubtestTable.numel_RT, subNum,[]); %for SPSS analysis 
        %% for error bar within subject design
        adjustRT = adjustErrorBar(Out.spssRTSubEptest, subNum);
        [mT eT cT gT] = grpstats(adjustRT,{mrSubtestTable.New mrSubtestTable.NE},{'mean', 'sem','numel','gname'});
        dataTestOut.mT = [dataTestOut.mT,mT];
        dataTestOut.eT = [dataTestOut.eT,eT];
    end
    picture(dataOut,dataTestOut,nEp,ntestEp);
catch ME
    disp(ME.message);
end
end
   % plot results 
function picture(dataOut,dataTestOut,nEp,ntestEp)
   %plot exp1
   figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
   set(gca,'Position',[0.25 0.16 0.68 0.68] );
   xlim([0 10]);
   ylim([0 45]);
   set(gca,'xtick',0:2:10);
   set(gca,'fontsize',14);
   set(gca,'fontname','Arial');
   errorbar(1:nEp, dataOut.mL(1: nEp,1), dataOut.eL(1: nEp,1),'k-o');
   errorbar(1:nEp, dataOut.mL(nEp+1:nEp*2,1), dataOut.eL(nEp+1:nEp*2,1),'k-*');
   legend('Repeated','Novel');
   set(legend,'box','off');
   text(0.9,42.3,'*');
   text(2.91,31,'*');
   text(3.9,27,'*');
   text(4.91,26,'*');
   text(5.9,23,'*');
   text(6.91,23,'*');
   text(7.91,22,'*');
   text(8.8,21,'**');
   text(9.92,22.2,'*');
   ylabel('Mean error rates (%)','fontsize',14,'fontweight','bold');
   xlabel('Epoch','fontsize',14,'fontweight','bold');
   text(-2.6,48,'A','fontsize',16);
   hold off;
   
   %plot exp2
   figure(); hold on;set(gcf,'Units','inches','Position',[1 1 7 5] );
   set(gca,'Position',[0.25 0.16 0.68 0.68] );
   set(gca,'ytick',0:10:50);
   set(gca,'xtick',0:2:14);
   set(gca,'fontsize',14);
   set(gca,'fontname','Arial');
   f1=errorbar(1 : nEp, dataOut.mL(1: nEp,2), dataOut.eL(1: nEp,2),'k-O');
   f2=errorbar(1 : nEp, dataOut.mL(nEp+1:nEp*2,2), dataOut.eL(nEp+1:nEp*2,2),'k-*');
   
   errorbar(nEp:nEp+ntestEp,[dataOut.mL(nEp,2);dataTestOut.mT(1,1)],[dataOut.eL(nEp,2);dataTestOut.eT(1,1)],'k--O');
   errorbar(nEp:nEp+ntestEp,[dataOut.mL(nEp*2,2);dataTestOut.mT(2,1)],[dataOut.eL(nEp*2,2);dataTestOut.eT(2,1)],'k--*');
   
   errorbar(nEp+ntestEp:nEp+ntestEp*2, [dataTestOut.mT(1,1); dataTestOut.mT(1,2)], [dataTestOut.eT(1,1); dataTestOut.eT(1,2)],'k--O');
   errorbar(nEp+ntestEp:nEp+ntestEp*2, [dataTestOut.mT(2,1); dataTestOut.mT(2,2)], [dataTestOut.eT(2,1); dataTestOut.eT(2,2)],'k--*');
   
   errorbar(nEp+ntestEp*2:nEp+ntestEp*3, [dataTestOut.mT(1,2); dataTestOut.mT(1,3)], [dataTestOut.eT(1,2); dataTestOut.eT(1,3)],'k--O');
   errorbar(nEp+ntestEp*2:nEp+ntestEp*3, [dataTestOut.mT(2,2); dataTestOut.mT(2,3)], [dataTestOut.eT(2,2); dataTestOut.eT(2,3)],'k--*');
   
   text(5.84,25.5,'**');
   text(8.8,24.5,'***');
   text(9.93,24,'*');
   text(3,42,'Learning phase','fontsize',14);
   text(11,42,'Test phase','fontsize',14);
   text(-2.5,53.6,'A','fontsize',16);
   ylabel('Mean error rates (%)','fontsize',14,'fontweight','bold');
   xlabel('Epoch','fontsize',14,'fontweight','bold');
   plot([10.5 10.5],[0,50],'k');
   legend([f1,f2],'Repeated','Novel');
   set(legend,'box','off');
   hold off;
   
   %plot exp3
   figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
   set(gca,'Position',[0.25 0.16 0.68 0.68] );
   xlim([0 10]);
   set(gca,'fontsize',14);
   set(gca,'fontname','Arial');
   f1=errorbar(1 : nEp, dataOut.mL(1: nEp,3), dataOut.eL(1: nEp,3),'k-O');
   f2=errorbar(1 : nEp, dataOut.mL(nEp+1:nEp*2,3), dataOut.eL(nEp+1:nEp*2,3),'k-*');
   text(3.95,29,'*');
   text(-2.6,48,'A','fontsize',16);
   ylabel('Mean error rates (%)','fontsize',14,'fontweight','bold');
   xlabel('Epoch','fontsize',14,'fontweight','bold');
   legend([f1,f2],'Repeated','Novel');
   set(legend,'box','off');
   hold off;
   
   %plot exp4
   figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
   set(gca,'Position',[0.25 0.16 0.68 0.68] );
   xlim([0 10]);
   set(gca,'fontsize',14);
   set(gca,'fontname','Arial');
   f1=errorbar(1 : nEp, dataOut.mL(1: nEp,4), dataOut.eL(1: nEp,4),'k-O');
   f2=errorbar(1 : nEp, dataOut.mL(nEp+1:nEp*2,4), dataOut.eL(nEp+1:nEp*2,4),'k-*');
   text(3.94,43.5,'*');
   text(-2.6,58,'A','fontsize',16);
   ylabel('Mean error rates (%)','fontsize',14,'fontweight','bold');
   xlabel('Epoch','fontsize',14,'fontweight','bold');
   legend([f1,f2],'Repeated','Novel');
   set(legend,'box','off');
   hold off;
end

function mrSubTrainTable = checkMissingCond(data,nEp, subNum)
% check and add missing rows (conditions)
    EpochStart = data.NE(1);
    EpochEnd = data.NE(end);
    mrSubTrainTable = dataset2table(data);
    rowNo = size(mrSubTrainTable,1); % how many exsiting rows
if rowNo < 2*nEp*subNum
    missingNewCount = [];
    missingNECount = [];
    missingNSubNo = {};
    missing_i = 0;
    for New = 1:2
        missingNewCount(New) = nEp*subNum - length( mrSubTrainTable.New(mrSubTrainTable.New == New-1) );
        if missingNewCount(New) > 0
            for Epoch = EpochStart:EpochEnd
                missingNECount(Epoch) = subNum - length( mrSubTrainTable.NE(mrSubTrainTable.New == New-1 & mrSubTrainTable.NE == Epoch) );
                if missingNECount(Epoch) > 0
                    missing_i = missing_i + 1;
                    missingNSubNo{missing_i} = setdiff(1:subNum, mrSubTrainTable.nSub(mrSubTrainTable.New == New-1 & mrSubTrainTable.NE == Epoch));
                    for adding_i = 1: size(missingNSubNo{missing_i},2)
                        currentRowNo = size(mrSubTrainTable,1)+1;
                        mrSubTrainTable.New(currentRowNo) = New-1;
                        mrSubTrainTable.NE(currentRowNo) = Epoch;
                        mrSubTrainTable.nSub(currentRowNo) = missingNSubNo{missing_i}(adding_i);
                        mrSubTrainTable.Properties.RowNames(currentRowNo) = {[num2str(New-1) '_' num2str(Epoch) '_' num2str(missingNSubNo{missing_i}(adding_i))]};
                    end
                end
            end
        end
    end
end
mrSubTrainTable.seqNo = mrSubTrainTable.New * nEp * subNum + (mrSubTrainTable.NE-1) * subNum + mrSubTrainTable.nSub;
mrSubTrainTable = sortrows(mrSubTrainTable, 'seqNo');
end