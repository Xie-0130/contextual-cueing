function dataProcessAll()

try
    close all
    % set configurate parameters
    nEp = 10;%number of epochs
    n.nBinEp = 5;%number of blocks in each epoch
    n.trlPerBlk = 24;%number of trials per block
    subNum = 15;%number of subjects
    nExp = 4;%number of experiment
    ntestEp = 1;
    
    % load the experiment data
    load('dataErr');
    load('dataValid');
    load('dataTestErr');
    load('dataTestValid');
    load('Recdata');
    
    % plot Mean error rates 
    errOut = ErrorProcess(dataErr,dataTestErr,nExp, subNum,nEp,ntestEp);   
    
    % process the valid data and plot Figure 
    dataOut = dataProcessValid(dataValid,dataTestValid,nExp, subNum,nEp,ntestEp);
    
    % recognition test 
    dataProcessRec(rec, subNum, nEp);

catch ME
    disp(ME.message);
end