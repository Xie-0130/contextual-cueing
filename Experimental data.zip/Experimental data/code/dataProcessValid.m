function Out = dataProcessValid(dataValid,dataTestValid,nExp, subNum,nEp,ntestEp)
try
    dataOut.mL = [ ];
    dataOut.eL = [];
    dataTestOut.mT = [ ];
    dataTestOut.eT = [];
    for iExp = 1:nExp
        fieldName = [ 'exp' num2str(iExp)];
        dataCurr = dataValid(dataValid.nExp == iExp, :);
        %training session RT analysis
        mrSubTrain = grpstats(dataCurr,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
        mrSubTrain.mean_RT = mrSubTrain.mean_RT .*1000;
        reshape(mrSubTrain.New, subNum,[])
        reshape(mrSubTrain.NE, subNum,[])
        reshape(mrSubTrain.nSub, subNum,[])
        Out.spssRTTrainEp = reshape(mrSubTrain.mean_RT, subNum,[]);   %for SPSS analysis   
       %% for error bar within subject design   
        adjustRT = adjustErrorBar(Out.spssRTTrainEp, subNum);         
        [mL eL cL gL] = grpstats(adjustRT,{mrSubTrain.New mrSubTrain.NE},{'mean', 'sem','numel','gname'}); 
        dataOut.mL = [dataOut.mL,mL];
        dataOut.eL = [dataOut.eL,eL];
    end
     %% transfer session (test1:i=11;test2:i=12;test3:i=13)
     for i = 11:13
     dataTestCurr = dataTestValid(dataTestValid.NE == i, :);
    mrSubtest = grpstats(dataTestCurr,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubtest.mean_RT = mrSubtest.mean_RT .*1000;
    Out.spssRTSubEptest = reshape(mrSubtest.mean_RT, subNum,[]);          
    %% for error bar within subject design   
     adjustRT = adjustErrorBar(Out.spssRTSubEptest, subNum);         
     [mT eT cT gT] = grpstats(adjustRT,{mrSubtest.New mrSubtest.NE},{'mean', 'sem','numel','gname'}); 
     dataTestOut.mT = [dataTestOut.mT,mT];
     dataTestOut.eT = [dataTestOut.eT,eT];
     end
    %%plot mean RTs 
    picture(dataOut,dataTestOut,nEp,ntestEp);
    
catch ME
    disp(ME.message);
end
end
     % plot results of training session
     function picture(dataOut,dataTestOut,nEp,ntestEp)
     %plot exp1
     figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
     set(gca,'Position',[0.25 0.16 0.68 0.68] );
     xlim([0 10]);
     set(gca,'xtick',0:2:10);
     set(gca,'ytick',600:20:720);
     set(gca,'fontsize',14);
     set(gca,'fontname','Arial');
     errorbar(1 : nEp, dataOut.mL(1: nEp,1), dataOut.eL(1: nEp,1),'k-O');
     errorbar(1 : nEp, dataOut.mL(nEp+1:nEp*2,1), dataOut.eL(nEp+1:nEp*2,1),'k-*');
     legend('Repeated','Novel');
     set(legend,'box','off');
     text(1.83,701.5,'**');
     text(2.91,687,'*');
     text(4.93,681,'*');
     text(5.73,664,'***');
     text(6.83,667,'**');
     text(7.83,667,'**');
     text(8.83,666,'**');
     text(9.83,677,'**');
     text(-2.6,730.5,'B','fontsize',16);
     ylabel('Mean response time (ms)','fontsize',14,'fontweight','bold');
     xlabel('Epoch','fontsize',14,'fontweight','bold');
     hold off;
     
     %plot exp2
     figure(); hold on;set(gcf,'Units','inches','Position',[1 1 7 5] );
     set(gca,'Position',[0.25 0.16 0.68 0.68] );
     set(gca,'ytick',550:40:850);
     set(gca,'xtick',0:2:14);
     set(gca,'fontsize',14);
     set(gca,'fontname','Arial');
     f1=errorbar(1 : nEp, dataOut.mL(1: nEp,2), dataOut.eL(1: nEp,2),'k-O');
     f2=errorbar(1 : nEp, dataOut.mL(nEp+1:nEp*2,2), dataOut.eL(nEp+1:nEp*2,2),'k-*');
     
     errorbar(nEp:nEp+ntestEp,[dataOut.mL(nEp,2);dataTestOut.mT(1,1)],[dataOut.eL(nEp,2);dataTestOut.eT(1,1)],'k--O');
     errorbar(nEp:nEp+ntestEp,[dataOut.mL(nEp*2,2);dataTestOut.mT(2,1)],[dataOut.eL(nEp*2,2);dataTestOut.eT(2,1)],'k--*');
     
     errorbar(nEp+ntestEp:nEp+ntestEp*2, [dataTestOut.mT(1,1); dataTestOut.mT(1,2)], [dataTestOut.eT(1,1); dataTestOut.eT(1,2)],'k--O');
     errorbar(nEp+ntestEp:nEp+ntestEp*2, [dataTestOut.mT(2,1); dataTestOut.mT(2,2)], [dataTestOut.eT(2,1); dataTestOut.eT(2,2)],'k--*');
     
     errorbar(nEp+ntestEp*2:nEp+ntestEp*3, [dataTestOut.mT(1,2);dataTestOut.mT(1,3)], [dataTestOut.eT(1,2); dataTestOut.eT(1,3)],'k--O');
     errorbar(nEp+ntestEp*2:nEp+ntestEp*3, [dataTestOut.mT(2,2); dataTestOut.mT(2,3)], [dataTestOut.eT(2,2);dataTestOut.eT(2,3)],'k--*');
     
     text(4.83,645,'**');
     text(6.91,640,'*');
     text(7.81,630,'**');
     text(9.82,630,'**');
     text(10.82,780,'**');
     text(11.81,776,'**');
     text(12.71,780,'***');
     text(3,800,'Learning phase','fontsize',14);
     text(11.2,800,'Test phase','fontsize',14);
     text(-2.5,870,'B','fontsize',16);
     ylabel('Mean response time (ms)','fontsize',14,'fontweight','bold')
     xlabel('Epoch','fontsize',14,'fontweight','bold');
     plot([10.5 10.5],[550,850],'k');
     legend([f1,f2],'Repeated','Novel');
     set(legend,'box','off');
     hold off;
     
     %plot exp3
     figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
     set(gca,'Position',[0.25 0.16 0.68 0.68] );
     xlim([0 10]);
     set(gca,'ytick',560:20:670);
     set(gca,'fontsize',14);
     set(gca,'fontname','Arial');
     f1=errorbar(1 : nEp, dataOut.mL(1: nEp,3), dataOut.eL(1: nEp,3),'k-O');
     f2=errorbar(1 : nEp, dataOut.mL(nEp+1:nEp*2,3), dataOut.eL(nEp+1:nEp*2,3),'k-*');
     text(-2.6,670,'B','fontsize',16);
     ylabel('Mean response time (ms)','fontsize',14,'fontweight','bold');
     xlabel('Epoch','fontsize',14,'fontweight','bold');
     legend([f1,f2],'Repeated','Novel');
     set(legend,'box','off');
     hold off;
     
     %exp4
     figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
     set(gca,'Position',[0.25 0.16 0.68 0.68] );
     xlim([0 10]);
     set(gca,'fontsize',14);
     set(gca,'fontname','Arial');
     f1=errorbar(1 : nEp, dataOut.mL(1: nEp,4), dataOut.eL(1: nEp,4),'k-O');
     f2=errorbar(1 : nEp, dataOut.mL(nEp+1:nEp*2,4), dataOut.eL(nEp+1:nEp*2,4),'k-*');
     text(6.84,582,'**');
     text(8.91,572,'*');
     text(-2.6,650,'B','fontsize',16);
     ylabel('Mean response time (ms)','fontsize',14,'fontweight','bold');
     xlabel('Epoch','fontsize',14,'fontweight','bold');
     legend([f1,f2],'Repeated','Novel');
     set(legend,'box','off');
     hold off;
    
     end
   
   

