%Name:                dataProcessRec.m
%
%Autor:               Xuelian Zang
%Description:         process recogntion data
%Date:                07/07/2014
function Out = dataProcessRec(rec, subNum, nEp)

 %% recognition test
    allOldArray = rec(rec.New == 0,:);
    hitArray =  allOldArray( allOldArray.RP==1,:);
    [m e c g] = grpstats(hitArray.New,{hitArray.New, hitArray.NB hitArray.nSub},{'mean', 'sem','numel','gname'}); 
    [mAll eAll cAll gAll] = grpstats(allOldArray.New,{allOldArray.New, allOldArray.NB allOldArray.nSub},{'mean', 'sem','numel','gname'}); 
    mHitRec = [];    
    for i=1:length(g)
        mHitRec(i,:) = [c(i) eval(g{i,1}) eval(g{i,2})  eval(g{i,3})];
        hitRate(i,1) =  mHitRec(i,1)/cAll(i);
        if hitRate(i,1) == 0
            hitRate(i,1) = 0.0001;
        elseif hitRate(i,1) == 1
            hitRate(i,1) = 0.9999;
        end
    end 
    % H1E1 
    hitRate = reshape(hitRate,subNum,[]);
    allNewArray = rec(rec.New == 1,:);
    crrRejectArray = allNewArray(allNewArray.RP == 2,:);
    [m e c g] = grpstats(crrRejectArray.New,{crrRejectArray.New, crrRejectArray.NB crrRejectArray.nSub}); 
    [mAll eAll cAll gAll] = ...
            grpstats(allNewArray.New,{allNewArray.New, allNewArray.NB allNewArray.nSub});
        
    mCrrRejRec = [];    
    for i=1:length(g)
            mCrrRejRec (i,:) = [c(i) eval(g{i,1}) eval(g{i,2})  eval(g{i,3})];
            falseAlarm(i,1) = 1 - mCrrRejRec(i,1)/cAll(i);
            %0, 1 correction
            if falseAlarm(i,1) == 0
                falseAlarm(i,1) = 0.0001;
            elseif falseAlarm(i,1) == 1
                falseAlarm(i,1) = 0.9999;
            end
    end 
    
    falseAlarm = reshape( falseAlarm,subNum, []);
    % H1E1   H2E1  
    hitFalseArray = [hitRate falseAlarm]; 
    %% calculate d'
    d = norminv(hitFalseArray (:,1))-norminv(hitFalseArray (:,2));
    Out.hitFalseArray = hitFalseArray;
    Out.d = d;