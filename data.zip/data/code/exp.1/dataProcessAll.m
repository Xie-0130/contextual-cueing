%% xuelian zang
%% 10/05/2013
%% analyse all the data

function dataProcessAll()

try
    close all
    % set configurate parameters
    nEp = 10;%number of epochs
    n.nBinEp = 5;%number of blocks in each epoch
    n.trlPerBlk = 24;%number of trials per block
    subNum = 15;%number of subjects
    
    % load the experiment data
    load('AllData');
    load('ErrData');

    % plot Mean error rates as a function of RT quartile subset(Figure 2A)
    errOut = ErrorProcess(err, nEp, subNum);   

    % process the valid data and plot Figure 2B
    dataOut = dataProcessValid(valid, nEp, subNum);

catch ME
    disp(ME.message);
end