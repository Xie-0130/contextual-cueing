function Out = dataProcessValid(valid, nEp, subNum)
try
     %%training session RT analysis
    %calculate mean RT of each subject and each condition 
    mrSubTrain = grpstats(valid,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubTrain.mean_RT = mrSubTrain.mean_RT .*1000;
    Out.mrSubTrain = mrSubTrain;
    reshape(mrSubTrain.New, subNum,[])
    reshape(mrSubTrain.NE, subNum,[])
    reshape(mrSubTrain.nSub, subNum,[])
    Out.spssRTTrainEp = reshape(mrSubTrain.mean_RT, subNum,[]);     
    
    %% for error bar within subject design   
    adjustRT = adjustErrorBar(Out.spssRTTrainEp, subNum);         
   [mL eL cL gL] = grpstats(adjustRT,{mrSubTrain.New mrSubTrain.NE},{'mean', 'sem','numel','gname'}); 
    
    % plot results of training session
    % RT
    figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
    set(gca,'Position',[0.25 0.16 0.68 0.68] );
    xlim([0 10]);
    set(gca,'ytick',560:20:670);
    set(gca,'fontsize',14);
    set(gca,'fontname','Arial');
    f1=errorbar(1 : nEp, mL(1: nEp), eL(1: nEp),'k-O');
    f2=errorbar(1 : nEp, mL(nEp+1:nEp*2), eL(nEp+1:nEp*2),'k-*');
    text(-2.6,670,'B','fontsize',16);
    ylabel('Mean response time (ms)','fontsize',14,'fontweight','bold');
    xlabel('Epoch','fontsize',14,'fontweight','bold');
    legend([f1,f2],'Repeated','Novel');
    set(legend,'box','off');
    hold off;
        
catch ME
    disp(ME.message);
end