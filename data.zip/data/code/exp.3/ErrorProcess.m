function Out = ErrorProcess(err, nEp, subNum)
try
 
    %calculate mean ER of each subject and each condition 
    mrSubTrain = grpstats(err,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubTrain.numel_RT = mrSubTrain.numel_RT ./60.*100;
    Out.mrSubTrain = mrSubTrain;
    reshape(mrSubTrain.New, subNum,[])
    reshape(mrSubTrain.NE, subNum,[])
    reshape(mrSubTrain.nSub, subNum,[])    
    Out.spssRTTrainEpErr = reshape(mrSubTrain.numel_RT, subNum,[]);      
       %% for error bar within subject design   
    adjustRT = adjustErrorBar(Out.spssRTTrainEpErr, subNum);         
    [mL eL cL gL] = grpstats(adjustRT,{mrSubTrain.New mrSubTrain.NE},{'mean', 'sem','numel','gname'}); 
    %ER
    figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
    set(gca,'Position',[0.25 0.16 0.68 0.68] );
    xlim([0 10]);
    set(gca,'fontsize',14);
    set(gca,'fontname','Arial');
    f1=errorbar(1 : nEp, mL(1: nEp), eL(1: nEp),'k-O');
    f2=errorbar(1 : nEp, mL(nEp+1:nEp*2), eL(nEp+1:nEp*2),'k-*');
    text(3.95,29,'*');
    text(-2.6,48,'A','fontsize',16);
    ylabel('Mean error rates (%)','fontsize',14,'fontweight','bold');
    xlabel('Epoch','fontsize',14,'fontweight','bold');
    legend([f1,f2],'Repeated','Novel');
    set(legend,'box','off');
    hold off;
    
catch ME
    disp(ME.message);
end