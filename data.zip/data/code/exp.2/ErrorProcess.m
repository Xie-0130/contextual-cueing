function Out = ErrorProcess(data, ntrainEp, ntestEp,subNum)
try
    %% training session ER analysis
    mrSubTrain = grpstats(data.err,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubTrainTable = checkMissingCond(mrSubTrain,ntrainEp, subNum);
    
    mrSubTrainTable.numel_RT = mrSubTrainTable.numel_RT ./0.6
    Out.mrSubTrainTable = mrSubTrainTable;
    
    reshape(mrSubTrainTable.New, subNum,[])
    reshape(mrSubTrainTable.NE, subNum,[])
    reshape(mrSubTrainTable.nSub, subNum,[])
    
    Out.spssRTTrainEp = reshape(mrSubTrainTable.numel_RT, subNum,[]);
    %% for error bar within subject design
    adjustRT = adjustErrorBar(Out.spssRTTrainEp, subNum);
    [mL eL cL gL] = grpstats(adjustRT,{Out.mrSubTrainTable.New Out.mrSubTrainTable.NE},{'mean', 'sem','numel','gname'});
    
    %% transfer session 1
    mrSubtest1 = grpstats(data.test1.err,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubtest1Table = checkMissingCond(mrSubtest1,ntestEp,subNum);
    
    mrSubtest1Table.numel_RT = mrSubtest1Table.numel_RT ./0.6;
    Out.mrSubtest1 = mrSubtest1Table;
    Out.spssRTSubEptest1 = reshape(mrSubtest1Table.mean_RT, subNum,[]);
    %% for error bar within subject design
    adjustRT = adjustErrorBar(Out.spssRTSubEptest1, subNum);
    [mT1 eT1 cT1 gT1] = grpstats(adjustRT,{mrSubtest1Table.New mrSubtest1Table.NE},{'mean', 'sem','numel','gname'});
    
    %% transfer session 2
    mrSubtest2 = grpstats(data.test2.err,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubtest2Table = checkMissingCond(mrSubtest2,ntestEp,subNum);
    
    mrSubtest2Table.numel_RT = mrSubtest2Table.numel_RT ./0.6;
    Out.mrSubtest2 = mrSubtest2Table;
    Out.spssRTmrSubEptest2 = reshape(mrSubtest2Table.mean_RT, subNum,[]);
    %% for error bar within subject design
    adjustRT = adjustErrorBar(Out.spssRTmrSubEptest2, subNum);
    [mT2 eT2 cT2 gT2] = grpstats(adjustRT,{mrSubtest2Table.New mrSubtest2Table.NE},{'mean', 'sem','numel','gname'});
    
    %% transfer session 3
    mrSubtest3 = grpstats(data.test3.err,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubtest3Table = checkMissingCond(mrSubtest3,ntestEp,subNum);
    
    mrSubtest1Table.numel_RT = mrSubtest1Table.numel_RT ./0.6;
    Out.mrSubtest3 = mrSubtest3Table;
    Out.spssRTSubEptest3 = reshape(mrSubtest3Table.mean_RT, subNum,[]);
    %% for error bar within subject design
    adjustRT = adjustErrorBar(Out.spssRTSubEptest3, subNum);
    [mT3 eT3 cT3 gT3] = grpstats(adjustRT,{mrSubtest3Table.New mrSubtest3Table.NE},{'mean', 'sem','numel','gname'});
    
    % plot results of training session
    %       figure(); hold on;set(gcf,'Units','inches','Position',[1 1 8.89 8.89*0.55] );
    figure(); hold on;set(gcf,'Units','inches','Position',[1 1 7 5] );
    set(gca,'Position',[0.25 0.16 0.68 0.68] );
    set(gca,'ytick',0:10:50);
    set(gca,'xtick',0:2:14);
    set(gca,'fontsize',14);
    set(gca,'fontname','Arial');
    f1=errorbar(1 : ntrainEp, mL(1: (ntrainEp)), eL(1: (ntrainEp)),'k-O');
    f2=errorbar(1 : ntrainEp, [mL(ntrainEp+1:ntrainEp*2)], [eL(ntrainEp+1:ntrainEp*2)],'k-*');
    
    errorbar(ntrainEp:ntrainEp+ntestEp,[mL(ntrainEp);mT1(1)],[eL(ntrainEp);eT1(1)],'k--O');
    errorbar(ntrainEp:ntrainEp+ntestEp,[mL(ntrainEp*2);mT1(2)],[eL(ntrainEp*2);eT1(2)],'k--*');
    
    errorbar(ntrainEp+ntestEp:ntrainEp+ntestEp*2, [mT1(1); mT2(1)], [eT1(1); eT2(1)],'k--O');
    errorbar(ntrainEp+ntestEp:ntrainEp+ntestEp*2, [mT1(2); mT2(2)], [eT1(2); eT2(2)],'k--*');
    
    errorbar(ntrainEp+ntestEp*2:ntrainEp+ntestEp*3, [mT2(1); mT3(1)], [eT2(1); eT3(1)],'k--O');
    errorbar(ntrainEp+ntestEp*2:ntrainEp+ntestEp*3, [mT2(2); mT3(2)], [eT2(2); eT3(2)],'k--*');
    
    text(5.84,25.5,'**');
    text(8.8,24.5,'***');
    text(9.93,24,'*');
    text(3,42,'Learning phase','fontsize',14);
    text(11,42,'Test phase','fontsize',14);
    text(-2.5,53.6,'A','fontsize',16);
    ylabel('Mean error rates (%)','fontsize',14,'fontweight','bold');
    xlabel('Epoch','fontsize',14,'fontweight','bold');
    plot([10.5 10.5],[0,50],'k');
    legend([f1,f2],'Repeated','Novel');
    set(legend,'box','off');
    hold off;
    
catch ME
    disp(ME.message);
end
end

function mrSubTrainTable = checkMissingCond(data,nEp,subNum)
% check and add missing rows (conditions)
EpochStart = data.NE(1);
EpochEnd = data.NE(end);
mrSubTrainTable = dataset2table(data);
rowNo = size(mrSubTrainTable,1); % how many exsiting rows
if rowNo < 2*nEp*subNum
    missingNewCount = [];
    missingNECount = [];
    missingNSubNo = {};
    missing_i = 0;
    for New = 1:2
        missingNewCount(New) = nEp*subNum - length( mrSubTrainTable.New(mrSubTrainTable.New == New-1) );
        if missingNewCount(New) > 0
            for Epoch = EpochStart:EpochEnd
                missingNECount(Epoch) = subNum - length( mrSubTrainTable.NE(mrSubTrainTable.New == New-1 & mrSubTrainTable.NE == Epoch) );
                if missingNECount(Epoch) > 0
                    missing_i = missing_i + 1;
                    missingNSubNo{missing_i} = setdiff(1:subNum, mrSubTrainTable.nSub(mrSubTrainTable.New == New-1 & mrSubTrainTable.NE == Epoch));
                    for adding_i = 1: size(missingNSubNo{missing_i},2)
                        currentRowNo = size(mrSubTrainTable,1)+1;
                        mrSubTrainTable.New(currentRowNo) = New-1;
                        mrSubTrainTable.NE(currentRowNo) = Epoch;
                        mrSubTrainTable.nSub(currentRowNo) = missingNSubNo{missing_i}(adding_i);
                        mrSubTrainTable.Properties.RowNames(currentRowNo) = {[num2str(New-1) '_' num2str(Epoch) '_' num2str(missingNSubNo{missing_i}(adding_i))]};
                    end
                end
            end
        end
    end
end
mrSubTrainTable.seqNo = mrSubTrainTable.New * nEp * subNum + (mrSubTrainTable.NE-1) * subNum + mrSubTrainTable.nSub;
mrSubTrainTable = sortrows(mrSubTrainTable, 'seqNo');
end