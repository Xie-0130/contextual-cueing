%% Author: xuelian zang
%% Date: 06/10/2019
%% Description: analyse contextual cueing data and plot the related results
%% Contact: lianlian81821@126.com

function dataProcessAll()

try
    clc;
    close all;
    clear all;
    %define the number of epoch and block    
    ntrainEp = 10;
    n.nBinEp = 5;
    n.trlPerBlk = 24;
    ntestEp = 1;
    subNum = 15;
    
    % load the experiment data
    load('AllData');
    load('ErrData');
    
    % plot Mean error rates as a function of RT quartile subset(Figure 3A)
    errOut = ErrorProcess(data, ntrainEp,ntestEp,subNum);   

    % process the valid data and plot Figure 3B
    dataOut = dataProcessValid(dataOut, ntrainEp,ntestEp, subNum);   
    
catch ME
    disp(ME.message);
end