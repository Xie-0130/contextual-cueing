function Out = dataProcessValid(valid, nEp, subNum)
try
    %training session RT analysis
  
    %Valid trials
    mrSubTrain = grpstats(valid,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubTrain.mean_RT = mrSubTrain.mean_RT .*1000;
    reshape(mrSubTrain.New, subNum,[])
    reshape(mrSubTrain.NE, subNum,[])
    reshape(mrSubTrain.nSub, subNum,[])
    
    Out.spssRTTrainEp = reshape(mrSubTrain.mean_RT, subNum,[]);          
 
    %% for error bar within subject design   
    adjustRT = adjustErrorBar(Out.spssRTTrainEp, subNum);         
    [mL eL cL gL] = grpstats(adjustRT,{mrSubTrain.New mrSubTrain.NE},{'mean', 'sem','numel','gname'}); 
 
     % plot results of training session
      figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
      set(gca,'Position',[0.25 0.16 0.68 0.68] );
      xlim([0 10]);
      set(gca,'xtick',0:2:10);
      set(gca,'ytick',600:20:720);
      set(gca,'fontsize',14);
      set(gca,'fontname','Arial');
     errorbar(1 : nEp, mL(1: nEp), eL(1: nEp),'k-O');
     errorbar(1 : nEp, mL(nEp+1:nEp*2), eL(nEp+1:nEp*2),'k-*');
    
     legend('Repeated','Novel');
     set(legend,'box','off');
     text(1.83,701.5,'**');
     text(2.91,687,'*');
     text(4.93,681,'*');
     text(5.73,664,'***');
     text(6.83,667,'**');
     text(7.83,667,'**'); 
     text(8.83,666,'**');
     text(9.83,677,'**');
     text(-2.6,730.5,'B','fontsize',16);
     ylabel('Mean response time (ms)','fontsize',14,'fontweight','bold');
     xlabel('Epoch','fontsize',14,'fontweight','bold');
     hold off;

catch ME
    disp(ME.message);
end