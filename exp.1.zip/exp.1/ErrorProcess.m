function Out = ErrorProcess(err, nEp, subNum)
try
  
    %Error trials
    mrSubTrain = grpstats(err,{'New','NE','nSub'},{'mean','numel','sem'},'DataVars','RT');
    mrSubTrain.numel_RT = mrSubTrain.numel_RT ./0.6;%Calculate error rate
    Out.mrSubTrain = mrSubTrain;
    reshape(mrSubTrain.New, subNum,[])
    reshape(mrSubTrain.NE, subNum,[])
    reshape(mrSubTrain.nSub, subNum,[])
    
    Out.spssRTTrainEp = reshape(mrSubTrain.numel_RT, subNum,[]);          
    %% for error bar within subject design   
    adjustRT = adjustErrorBar(Out.spssRTTrainEp, subNum);         
    [mL eL cL gL] = grpstats(adjustRT,{mrSubTrain.New mrSubTrain.NE},{'mean', 'sem','numel','gname'}); 
            
   % plot results of training session
    figure(); hold on;set(gcf,'Units','inches','Position',[1 1 5 5] );
    set(gca,'Position',[0.25 0.16 0.68 0.68] );
    xlim([0 10]);
    ylim([0 45]);
    set(gca,'xtick',0:2:10);
    set(gca,'fontsize',14);
    set(gca,'fontname','Arial');
    errorbar(1:nEp, mL(1: nEp), eL(1: nEp),'k-o');
    errorbar(1:nEp, mL(nEp+1:nEp*2), eL(nEp+1:nEp*2),'k-*');
    legend('Repeated','Novel');
    set(legend,'box','off');
    text(0.9,42.3,'*');
    text(2.91,31,'*');
    text(3.9,27,'*');
    text(4.91,26,'*');
    text(5.9,23,'*');
    text(6.91,23,'*'); 
    text(7.91,22,'*');
    text(8.8,21,'**');
    text(9.92,22.2,'*');
    ylabel('Mean error rates (%)','fontsize',14,'fontweight','bold');
    xlabel('Epoch','fontsize',14,'fontweight','bold');
    text(-2.6,48,'A','fontsize',16);
    hold off;
    

catch ME
    disp(ME.message);
end